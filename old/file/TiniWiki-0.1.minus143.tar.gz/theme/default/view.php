<?=syntax_parsing($pagedata)?>

