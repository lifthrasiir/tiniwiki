<?php
############################################################
## TiniWiki version 0.1
##   page: index.php (redirection to FrontPage)
## Script by Tokigun <zenith@tokigun.net>
############################################################

echo "<?xml version=\"1.0\" encoding=\"EUC-KR\" ?>\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">

<head>
	<title>Moving to TiniWiki...</title>
	<meta http-equiv="refresh" content="1; url=wiki.php/" />
</head>

<body>
<p>
	<b>Moving to TiniWiki...</b><br />
	Click <a href="wiki.php/">here</a> if don't enter automatically.
</p>
</body>

</html>

